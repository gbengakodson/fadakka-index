# Android permissions and configuration
from kivy.config import Config
Config.set('kivy', 'window_icon', 'assets/icon.png')


from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.progressbar import MDProgressBar
from kivymd.uix.card import MDCard
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.dialog import MDDialog
from kivymd.uix.selectioncontrol import MDSwitch
from kivymd.uix.textfield import MDTextField
from kivy.clock import Clock
from kivy.uix.scrollview import ScrollView
from kivy.uix.boxlayout import BoxLayout
from kivy.graphics import Color, Rectangle
from kivy.metrics import dp
from kivy.core.window import Window
from services.fadakka_engine import FadakkaEngine
from threading import Thread
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from io import BytesIO
from kivy.core.image import Image as CoreImage
from kivy.uix.image import Image
import numpy as np
import json
import os

# Mobile shape
# Window.size = (400, 700)


class PriceChart(BoxLayout):
    """Mini chart"""
    
    def __init__(self, weekly_prices, fadakka_value, current_price, **kwargs):
        super().__init__(**kwargs)
        self.size_hint_y = None
        self.height = dp(70)
        self.orientation = 'vertical'
        self.padding = [dp(2), dp(1), dp(2), dp(1)]
        self.create_chart(weekly_prices, fadakka_value, current_price)
    
    def create_chart(self, weekly_prices, fadakka_value, current_price):
        plt.clf()
        fig, ax = plt.subplots(figsize=(3.5, 1.0), facecolor='#0d0d12')
        
        if weekly_prices and len(weekly_prices) > 1:
            dates = list(range(len(weekly_prices)))
            ax.plot(dates, weekly_prices, color='#4da6ff', linewidth=1.2)
            ax.axhline(y=fadakka_value, color='#e6b800', linewidth=0.8, linestyle='--')
            ax.fill_between(dates, weekly_prices, fadakka_value,
                           where=(np.array(weekly_prices) >= fadakka_value),
                           color='#ff3333', alpha=0.10)
            ax.fill_between(dates, weekly_prices, fadakka_value,
                           where=(np.array(weekly_prices) < fadakka_value),
                           color='#33cc33', alpha=0.10)
            dot_color = '#33cc33' if current_price < fadakka_value else '#ff3333'
            ax.scatter([len(dates)-1], [current_price], color=dot_color, s=20, zorder=5)
        
        ax.set_facecolor('#0d0d12')
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['bottom'].set_color('#2a2a2a')
        ax.spines['left'].set_color('#2a2a2a')
        ax.tick_params(colors='#555555', labelsize=5, pad=1)
        ax.set_xticks([])
        plt.tight_layout(pad=0.2)
        
        buf = BytesIO()
        plt.savefig(buf, format='png', dpi=90, facecolor='#0d0d12', edgecolor='none', bbox_inches='tight')
        buf.seek(0)
        img = CoreImage(buf, ext='png')
        self.add_widget(Image(texture=img.texture, size_hint_y=1))
        plt.close()


class AssetDetailCompact(MDCard):
    """Compact asset detail card"""
    
    def __init__(self, result, engine, **kwargs):
        super().__init__(**kwargs)
        self.size_hint_y = None
        extra_rows = 1 if (result.get('dividend') or result.get('interest_rate_diff')) else 0
        self.height = dp(140 + (extra_rows * 15))
        self.padding = dp(6)
        self.radius = dp(8)
        self.elevation = 2
        self.md_bg_color = (0.09, 0.09, 0.12, 1)
        
        if result['status'] == 'CHEAP':
            accent = (0.2, 0.85, 0.2, 1)
            status_txt = "CHEAP"
        else:
            accent = (0.95, 0.25, 0.25, 1)
            status_txt = "EXPENSIVE"
        
        main = MDBoxLayout(orientation='vertical', spacing=dp(2))
        
        # Row 1: Symbol + Status + Price
        row1 = MDBoxLayout(orientation='horizontal', spacing=dp(3), size_hint_y=0.18)
        
        sym_box = MDBoxLayout(orientation='vertical', size_hint_x=0.35)
        sym_box.add_widget(MDLabel(
            text=result['symbol'], font_style="Subtitle2", bold=True,
            theme_text_color="Custom", text_color=(1, 1, 1, 1), shorten=True
        ))
        sym_box.add_widget(MDLabel(
            text=result['type'], font_style="Overline",
            theme_text_color="Custom", text_color=(0.4, 0.4, 0.4, 1), shorten=True
        ))
        
        stat_box = MDBoxLayout(orientation='vertical', size_hint_x=0.3)
        stat_box.add_widget(MDLabel(
            text=f"{result['percentage_diff']:+.1f}%", font_style="Subtitle2", bold=True,
            theme_text_color="Custom", text_color=accent, halign="center"
        ))
        stat_box.add_widget(MDLabel(
            text=status_txt, font_style="Overline", bold=True,
            theme_text_color="Custom", text_color=accent, halign="center"
        ))
        
        price_box = MDBoxLayout(orientation='vertical', size_hint_x=0.35)
        price_box.add_widget(MDLabel(
            text=f"${result['current_price']:.2f}", font_style="Subtitle2",
            theme_text_color="Custom", text_color=(1, 1, 1, 1), halign="right"
        ))
        price_box.add_widget(MDLabel(
            text=f"Fadakka: ${result['fadakka_index']:.2f}", font_style="Overline",
            theme_text_color="Custom", text_color=(0.9, 0.7, 0.2, 1), halign="right"
        ))
        
        row1.add_widget(sym_box)
        row1.add_widget(stat_box)
        row1.add_widget(price_box)
        main.add_widget(row1)
        
        # Row 2: OHLC
        row2 = MDBoxLayout(orientation='horizontal', spacing=dp(2), size_hint_y=0.14)
        ohlc_vals = {'O': None, 'H': None, 'L': None, 'C': None}
        try:
            ticker = engine.get_ticker(result['symbol'])
            df = ticker.history(period='5d')
            if not df.empty and len(df) >= 1:
                ohlc_vals = {
                    'O': df['Open'].iloc[-1], 'H': df['High'].iloc[-1],
                    'L': df['Low'].iloc[-1],
                    'C': df['Close'].iloc[-2] if len(df) > 1 else None
                }
        except:
            pass
        
        for label, value, col in [
            ('O', ohlc_vals['O'], (0.6,0.6,0.6,1)),
            ('H', ohlc_vals['H'], (0.2,0.85,0.2,1)),
            ('L', ohlc_vals['L'], (0.95,0.25,0.25,1)),
            ('C', ohlc_vals['C'], (0.6,0.6,0.6,1))
        ]:
            item = MDBoxLayout(orientation='vertical', size_hint_x=0.25)
            item.add_widget(MDLabel(text=label, font_style="Overline",
                theme_text_color="Custom", text_color=(0.35,0.35,0.35,1), halign="center", font_size="7sp"))
            item.add_widget(MDLabel(text=f"{value:.2f}" if value else "-", font_style="Caption",
                theme_text_color="Custom", text_color=col, halign="center", font_size="8sp"))
            row2.add_widget(item)
        main.add_widget(row2)

        
        # Row 2.5: Extra Info (Dividend/Interest Rate)
        extra_info = result.get('dividend') or result.get('interest_rate_diff')
        if extra_info:
            row_extra = MDBoxLayout(orientation='horizontal', spacing=dp(2), size_hint_y=0.12)
            
            if 'dividend' in result:
                div = result['dividend']
                items = [
                    ('Div Yield', f"{div.get('dividend_yield', 'N/A')}%", (0.8, 0.8, 0.2, 1)),
                    ('Annual', f"${div.get('annual_dividend', 0):.3f}", (0.7, 0.7, 0.3, 1)),
                    ('Payout', f"{div.get('payout_ratio', 'N/A')}%", (0.6, 0.6, 0.4, 1)),
                    ('Grade', f"{div.get('dividend_grade', 'N/A')}", (0.9, 0.7, 0.2, 1)),
                ]
            elif 'interest_rate_diff' in result:
                rate = result['interest_rate_diff']
                carry_color = (0.2, 0.8, 0.2, 1) if rate['carry_direction'] == 'LONG' else (0.95, 0.3, 0.3, 1)
                items = [
                    ('Base Rate', f"{rate['base_rate']}%", (0.7, 0.7, 0.7, 1)),
                    ('Quote Rate', f"{rate['quote_rate']}%", (0.7, 0.7, 0.7, 1)),
                    ('Rate Diff', f"{rate['rate_diff']:+.2f}%", carry_color),
                    ('Carry', f"Go {rate['carry_direction']}", carry_color),
                ]
            else:
                items = []
            
            for label, value, col in items:
                item = MDBoxLayout(orientation='vertical', size_hint_x=0.25)
                item.add_widget(MDLabel(
                    text=label, font_style="Overline",
                    theme_text_color="Custom", text_color=(0.35,0.35,0.35,1),
                    halign="center", font_size="6sp"
                ))
                item.add_widget(MDLabel(
                    text=value, font_style="Caption",
                    theme_text_color="Custom", text_color=col,
                    halign="center", font_size="7sp"
                ))
                row_extra.add_widget(item)
            
            main.add_widget(row_extra)





        # Row 3: Chart
        weekly_prices = []
        try:
            ticker = engine.get_ticker(result['symbol'])
            df = ticker.history(period='18mo')
            if not df.empty:
                weekly_prices = df['Close'].resample('W').last().dropna().tolist()
        except:
            pass
        
        chart = PriceChart(weekly_prices, result['fadakka_index'], result['current_price'])
        main.add_widget(chart)
        
        # Row 4: Bar
        bar_box = MDBoxLayout(orientation='horizontal', spacing=dp(2), size_hint_y=0.05)
        bar_box.add_widget(MDLabel(text="Distance:", font_style="Overline",
            theme_text_color="Custom", text_color=(0.4,0.4,0.4,1), size_hint_x=0.2, font_size="6sp"))
        bar_box.add_widget(MDProgressBar(value=min(abs(result['percentage_diff']), 100), color=accent, size_hint_x=0.8))
        main.add_widget(bar_box)
        
        self.add_widget(main)


class SettingsDialog:
    """Settings dialog content"""
    
    def __init__(self, app):
        self.app = app
        self.dialog = None
        
        content = MDBoxLayout(orientation='vertical', spacing=dp(15), padding=dp(20), size_hint_y=None)
        content.height = dp(300)
        
        # Auto-refresh toggle
        refresh_box = MDBoxLayout(orientation='horizontal', spacing=dp(10), size_hint_y=None, height=dp(40))
        refresh_box.add_widget(MDLabel(text="Auto-refresh", font_style="Body1"))
        self.refresh_switch = MDSwitch(active=app.auto_refresh_enabled)
        refresh_box.add_widget(self.refresh_switch)
        content.add_widget(refresh_box)
        
        # Refresh interval
        interval_box = MDBoxLayout(orientation='horizontal', spacing=dp(10), size_hint_y=None, height=dp(40))
        interval_box.add_widget(MDLabel(text="Interval (min):", font_style="Body1", size_hint_x=0.5))
        self.interval_field = MDTextField(
            text=str(app.refresh_interval), size_hint_x=0.5,
            input_filter='int', halign="center"
        )
        interval_box.add_widget(self.interval_field)
        content.add_widget(interval_box)
        
        # Notifications toggle
        notif_box = MDBoxLayout(orientation='horizontal', spacing=dp(10), size_hint_y=None, height=dp(40))
        notif_box.add_widget(MDLabel(text="Notifications", font_style="Body1"))
        self.notif_switch = MDSwitch(active=app.notifications_enabled)
        notif_box.add_widget(self.notif_switch)
        content.add_widget(notif_box)
        
        # Alert threshold
        alert_box = MDBoxLayout(orientation='horizontal', spacing=dp(10), size_hint_y=None, height=dp(40))
        alert_box.add_widget(MDLabel(text="Alert threshold %:", font_style="Body1", size_hint_x=0.5))
        self.threshold_field = MDTextField(
            text=str(app.alert_threshold), size_hint_x=0.5,
            input_filter='int', halign="center"
        )
        alert_box.add_widget(self.threshold_field)
        content.add_widget(alert_box)
        
        # Buttons
        btn_box = MDBoxLayout(orientation='horizontal', spacing=dp(10), size_hint_y=None, height=dp(45))
        btn_box.add_widget(MDFlatButton(text="CANCEL", on_release=lambda x: self.dialog.dismiss()))
        btn_box.add_widget(MDRaisedButton(text="SAVE", on_release=self.save_settings))
        content.add_widget(btn_box)
        
        self.dialog = MDDialog(
            title="Settings",
            type="custom",
            content_cls=content,
        )
    
    def open(self):
        self.dialog.open()
    
    def save_settings(self, instance):
        try:
            self.app.auto_refresh_enabled = self.refresh_switch.active
            self.app.refresh_interval = int(self.interval_field.text)
            self.app.notifications_enabled = self.notif_switch.active
            self.app.alert_threshold = int(self.threshold_field.text)
            self.app.save_settings_to_file()
            self.app.apply_settings()
        except:
            pass
        self.dialog.dismiss()


class HomeScreen(MDScreen):
    """Main Dashboard Screen"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.engine = FadakkaEngine()
        self.all_results = []
        self.is_cancelled = False
        self.current_page = 0
        self.per_page = 3
        self.refresh_event = None
        
        # Settings defaults
        self.auto_refresh_enabled = False
        self.refresh_interval = 30  # minutes
        self.notifications_enabled = True
        self.alert_threshold = 10  # percentage
        
        # Load settings
        self.load_settings()
        
        with self.canvas.before:
            Color(0.04, 0.04, 0.06, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        self.layout = BoxLayout(
            orientation='vertical',
            padding=[dp(8), dp(10), dp(8), dp(8)],
            spacing=dp(4)
        )
        
        # Header row
        header_row = MDBoxLayout(orientation='horizontal', size_hint_y=0.06, spacing=dp(5))
        
        header_row.add_widget(MDLabel(text="", size_hint_x=0.1))  # Spacer
        
        title_box = MDBoxLayout(orientation='vertical', size_hint_x=0.7)
        title_box.add_widget(MDLabel(
            text="FADAKKA INDEX", halign="center", font_style="H6", bold=True,
            theme_text_color="Custom", text_color=(0.9, 0.7, 0.2, 1)
        ))
        title_box.add_widget(MDLabel(
            text="99-Week EMA Analysis", halign="center", font_style="Overline",
            theme_text_color="Custom", text_color=(0.4, 0.4, 0.4, 1)
        ))
        header_row.add_widget(title_box)
        
        # Settings gear
        settings_btn = MDIconButton(
            icon="cog", size_hint_x=0.1,
            theme_text_color="Custom", text_color=(0.5, 0.5, 0.5, 1),
            on_release=self.open_settings
        )
        header_row.add_widget(settings_btn)
        self.layout.add_widget(header_row)
        
        # Summary
        self.summary_card = MDCard(
            size_hint_y=0.04, padding=dp(5), radius=dp(6), elevation=1,
            md_bg_color=(0.1, 0.1, 0.13, 1)
        )
        self.summary_label = MDLabel(
            text="Press SCAN to begin", halign="center", font_style="Caption",
            theme_text_color="Custom", text_color=(0.5, 0.5, 0.5, 1)
        )
        self.summary_card.add_widget(self.summary_label)
        self.layout.add_widget(self.summary_card)
        
        # Dropdown
        self.dropdown_btn = MDFlatButton(
            text="Select Asset  ▼", size_hint_y=0.04,
            theme_text_color="Custom", text_color=(0.9, 0.7, 0.2, 1),
            on_release=self.open_dropdown
        )
        self.layout.add_widget(self.dropdown_btn)
        self.dropdown_menu = None
        
        # Status & Progress
        self.status_label = MDLabel(
            text="Ready", halign="center", font_style="Overline",
            theme_text_color="Custom", text_color=(0.35, 0.35, 0.35, 1), size_hint_y=0.025
        )
        self.layout.add_widget(self.status_label)
        
        self.progress = MDProgressBar(
            size_hint_x=0.9, pos_hint={'center_x': 0.5}, size_hint_y=0.008,
            color=(0.9, 0.7, 0.2, 1)
        )
        self.progress.value = 0
        self.layout.add_widget(self.progress)
        
        # Asset details (scrollable)
        self.scroll = ScrollView(size_hint_y=0.67, bar_color=(0.2, 0.2, 0.2, 1))
        self.detail_layout = MDBoxLayout(
            orientation='vertical', spacing=dp(5), padding=[0, dp(2), 0, 0], size_hint_y=None
        )
        self.detail_layout.bind(minimum_height=self.detail_layout.setter('height'))
        self.scroll.add_widget(self.detail_layout)
        self.layout.add_widget(self.scroll)
        
        # Navigation
        nav_row = MDBoxLayout(orientation='horizontal', size_hint_y=0.05, spacing=dp(3))
        self.prev_btn = MDRaisedButton(
            text="< PREV", size_hint_x=0.3, md_bg_color=(0.12, 0.12, 0.17, 1),
            font_style="Caption", on_release=self.prev_page
        )
        self.page_label = MDLabel(
            text="Page 1", halign="center", font_style="Caption",
            theme_text_color="Custom", text_color=(0.5, 0.5, 0.5, 1), size_hint_x=0.4
        )
        self.next_btn = MDRaisedButton(
            text="NEXT >", size_hint_x=0.3, md_bg_color=(0.12, 0.12, 0.17, 1),
            font_style="Caption", on_release=self.next_page
        )
        nav_row.add_widget(self.prev_btn)
        nav_row.add_widget(self.page_label)
        nav_row.add_widget(self.next_btn)
        self.layout.add_widget(nav_row)
        
        # Bottom buttons
        btn_row = MDBoxLayout(orientation='horizontal', size_hint_y=0.055, spacing=dp(5))
        
        self.scan_btn = MDRaisedButton(
            text="SCAN", size_hint_x=0.65,
            md_bg_color=(0.9, 0.7, 0.2, 1), text_color=(0.05, 0.05, 0.07, 1),
            font_style="Button", on_release=self.start_analysis
        )
        
        self.refresh_toggle_btn = MDRaisedButton(
            text="AUTO: OFF", size_hint_x=0.35,
            md_bg_color=(0.15, 0.15, 0.2, 1),
            font_style="Caption", on_release=self.toggle_auto_refresh
        )
        
        btn_row.add_widget(self.scan_btn)
        btn_row.add_widget(self.refresh_toggle_btn)
        self.layout.add_widget(btn_row)
        
        self.add_widget(self.layout)
        
        # Try loading saved data
        self.load_saved_data()
    
    def _update_rect(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size
    
    def open_settings(self, instance):
        SettingsDialog(self).open()
    
    def toggle_auto_refresh(self, instance):
        self.auto_refresh_enabled = not self.auto_refresh_enabled
        self.apply_settings()
    
    def load_settings(self):
        try:
            if os.path.exists('settings.json'):
                with open('settings.json', 'r') as f:
                    data = json.load(f)
                    self.auto_refresh_enabled = data.get('auto_refresh', False)
                    self.refresh_interval = data.get('interval', 30)
                    self.notifications_enabled = data.get('notifications', True)
                    self.alert_threshold = data.get('threshold', 10)
        except:
            pass
    
    def save_settings_to_file(self):
        try:
            with open('settings.json', 'w') as f:
                json.dump({
                    'auto_refresh': self.auto_refresh_enabled,
                    'interval': self.refresh_interval,
                    'notifications': self.notifications_enabled,
                    'threshold': self.alert_threshold
                }, f)
        except:
            pass
    
    def apply_settings(self):
        # Update button text
        if self.auto_refresh_enabled:
            self.refresh_toggle_btn.text = f"AUTO: {self.refresh_interval}m"
            self.refresh_toggle_btn.md_bg_color = (0.2, 0.6, 0.2, 1)
            self.start_auto_refresh()
        else:
            self.refresh_toggle_btn.text = "AUTO: OFF"
            self.refresh_toggle_btn.md_bg_color = (0.15, 0.15, 0.2, 1)
            self.stop_auto_refresh()
        
        self.save_settings_to_file()
    
    def start_auto_refresh(self):
        self.stop_auto_refresh()
        self.refresh_event = Clock.schedule_interval(
            lambda dt: self.auto_refresh_tick(),
            self.refresh_interval * 60
        )
        self.status_label.text = f"Auto-refresh every {self.refresh_interval}min"
    
    def stop_auto_refresh(self):
        if self.refresh_event:
            self.refresh_event.cancel()
            self.refresh_event = None
    
    def auto_refresh_tick(self):
        if self.auto_refresh_enabled and not self.scan_btn.disabled:
            self.start_analysis(None)
    
    def open_dropdown(self, instance):
        if not self.all_results:
            return
    
        # Build menu with ALL assets
        menu_items = []
    
        # Group by type
        types_order = ['Stock', 'NG Stock', 'Currency', 'Crypto']
        grouped = {}
        for res in self.all_results:
            t = res['type']
            if t not in grouped:
                grouped[t] = []
            grouped[t].append(res)
    
        for asset_type in types_order:
            if asset_type in grouped:
                # Add type header
                label = asset_type
                if asset_type == 'NG Stock':
                    label = 'NG STOCK'
                elif asset_type == 'Currency':
                    label = 'CURRENCY'
                elif asset_type == 'Crypto':
                    label = 'CRYPTO'
                elif asset_type == 'Stock':
                    label = 'STOCK'
            
                menu_items.append({
                    "text": f"--- {label}S ---",
                    "viewclass": "OneLineListItem",
                    "disabled": True
                })
                for res in grouped[asset_type]:
                    cheap_mark = "[CHEAP]" if res['status'] == 'CHEAP' else "[EXP]"
                    menu_items.append({
                        "text": f"{cheap_mark} {res['symbol']}  {res['percentage_diff']:+.1f}%",
                        "viewclass": "OneLineListItem",
                        "on_release": lambda x=self.all_results.index(res): self.jump_to_asset(x),
                    })
    
        # Commodities and other types
        for key in grouped:
            if key not in types_order:
                menu_items.append({
                    "text": f"--- {key.upper()}S ---",
                    "viewclass": "OneLineListItem",
                    "disabled": True
                })
                for res in grouped[key]:
                    cheap_mark = "[CHEAP]" if res['status'] == 'CHEAP' else "[EXP]"
                    menu_items.append({
                        "text": f"{cheap_mark} {res['symbol']}  {res['percentage_diff']:+.1f}%",
                        "viewclass": "OneLineListItem",
                        "on_release": lambda x=self.all_results.index(res): self.jump_to_asset(x),
                    })
    
        self.dropdown_menu = MDDropdownMenu(
            caller=instance, items=menu_items, width_mult=4, max_height=dp(300)
        )
        self.dropdown_menu.open()
    
    def jump_to_asset(self, index):
        if self.dropdown_menu:
            self.dropdown_menu.dismiss()
        self.current_page = index // self.per_page
        self.show_page()
    
    def next_page(self, instance):
        max_page = max(0, (len(self.all_results) - 1) // self.per_page)
        if self.current_page < max_page:
            self.current_page += 1
            self.show_page()
    
    def prev_page(self, instance):
        if self.current_page > 0:
            self.current_page -= 1
            self.show_page()
    
    def show_page(self):
        self.detail_layout.clear_widgets()
        if not self.all_results:
            return
        
        start = self.current_page * self.per_page
        end = min(start + self.per_page, len(self.all_results))
        
        for i in range(start, end):
            card = AssetDetailCompact(self.all_results[i], self.engine)
            self.detail_layout.add_widget(card)
        
        max_page = max(0, (len(self.all_results) - 1) // self.per_page)
        self.page_label.text = f"Page {self.current_page + 1}/{max_page + 1}"
        self.detail_layout.height = (end - start) * dp(148)
        self.scroll.scroll_y = 1
    
    def load_saved_data(self):
        saved = self.engine.load_results()
        if saved:
            self.all_results = saved
            self.display_results(skip_save=True)
    
    def start_analysis(self, instance):
        self.scan_btn.disabled = True
        self.scan_btn.text = "SCANNING..."
        self.status_label.text = "Fetching data..."
        self.progress.value = 0
        self.detail_layout.clear_widgets()
        self.is_cancelled = False
        self.current_page = 0
        
        Thread(target=self.run_analysis, daemon=True).start()
    
    def run_analysis(self):
        self.all_results = []
        all_assets = self.engine.get_all_asset_list()
        total = len(all_assets)
        
        for i, asset in enumerate(all_assets):
            if self.is_cancelled:
                break
            self.update_status(f"[{i+1}/{total}] {asset['symbol']}")
            result = self.engine.analyze_single_asset(asset['symbol'], asset['type'])
            if result:
                self.all_results.append(result)
            self.update_progress(i + 1, total)
        
        Clock.schedule_once(lambda dt: self.display_results())
    
    def update_status(self, msg):
        Clock.schedule_once(lambda dt: setattr(self.status_label, 'text', msg))
    
    def update_progress(self, current, total):
        val = (current / total) * 100
        Clock.schedule_once(lambda dt: setattr(self.progress, 'value', val))
    
    def display_results(self, skip_save=False):
        self.scan_btn.disabled = False
        self.scan_btn.text = "REFRESH"
        self.progress.value = 100
        
        if not self.all_results:
            self.summary_label.text = "No data. Check connection."
            return
        
        summary = self.engine.get_summary(self.all_results)
        color = (0.2, 0.85, 0.2, 1) if summary['market_sentiment'] == 'BEARISH' else (0.95, 0.25, 0.25, 1)
        
        self.summary_label.text = (
            f"{summary['market_sentiment']} | Cheap: {summary['cheap_count']} | "
            f"Expensive: {summary['expensive_count']} | Total: {summary['total']}"
        )
        self.summary_label.text_color = color
        self.status_label.text = f"Updated: {self.all_results[0]['last_updated']}"
        
        self.current_page = 0
        self.show_page()
        
        # Save data
        if not skip_save:
            self.engine.save_results(self.all_results)
        
        # Check for alerts
        if self.notifications_enabled:
            self.check_alerts()
    
    def check_alerts(self):
        """Check for significant changes and notify"""
        alerts = []
        for res in self.all_results:
            if abs(res['percentage_diff']) > self.alert_threshold:
                alerts.append(res)
        
        if alerts:
            msg = f"{len(alerts)} assets exceed {self.alert_threshold}% threshold"
            self.show_notification("Fadakka Alert", msg)
    
    def show_notification(self, title, message):
        """Show notification dialog"""
        try:
            from plyer import notification
            notification.notify(title=title, message=message, timeout=5)
        except:
            pass
    
    def on_stop(self):
        """Called when app closes"""
        self.stop_auto_refresh()
        if self.all_results:
            self.engine.save_results(self.all_results)


class FadakkaApp(MDApp):
    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Amber"
        self.title = "Fadakka Index"
        return HomeScreen()
    
    def on_stop(self):
        if hasattr(self, 'root'):
            self.root.on_stop()


if __name__ == "__main__":
    FadakkaApp().run()